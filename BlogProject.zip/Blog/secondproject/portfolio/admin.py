from django.contrib import admin
from .models import Portfolio

admin.site.register(Portfolio)

# Register your models here.
